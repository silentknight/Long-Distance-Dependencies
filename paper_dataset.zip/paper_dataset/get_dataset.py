f = open("wikitext-103/train")
lines = f.readlines()
data = f.read()
f.close()

f = open("Wiki_sample_4","w")
for i in range(1,45000):
	f.write(lines[1500000+i])
f.close()